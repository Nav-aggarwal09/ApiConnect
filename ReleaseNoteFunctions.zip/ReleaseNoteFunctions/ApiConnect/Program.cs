﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using System.IO;


namespace ApiConnect
{
    class Program
    {

        static void Main(string[] args)
        {
            //RestClient rClient = new RestClient();
            //rClient.endPoint = txtRequestURI.Text;

            string strResponse = string.Empty;

            //strResponse = rClient.makeRequest();


        }
    }
}