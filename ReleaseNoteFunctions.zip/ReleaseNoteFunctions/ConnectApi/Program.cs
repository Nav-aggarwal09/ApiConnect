﻿using System;
using System.IO;
using System.Net;

namespace ConnectApi
{
    class Program
    {
        static void Main(string[] args)
        {
            string userName = "arnav0908";
            string userPassword = "arnavaggarwal";
            string authType = "Basic";


            //Open Request
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("https://socedo.atlassian.net/rest/api/latest/issue/SOC-3536/transitions?expand=transitions.fields");
            //JIRA API needs encoding of credentials for authenitatication
            String authHeader = System.Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes(userName + ":" + userPassword));

            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";
            Console.WriteLine(authHeader); // To double check encoding
            httpWebRequest.Headers.Add("Authorization", authType + " " + authHeader);

            

            //This packages the data to be transmitted in JSON format
            
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {

                string jsonData = "{\"update\":{}," +
                                  "\"transition\":{"
                                  +
                                  "\"id\":\"11\"}}";


                httpWebRequest.Headers.Add("Data", jsonData);
                streamWriter.Write(jsonData); 
                streamWriter.Flush();
                streamWriter.Close();
            }
            Console.WriteLine(httpWebRequest.Headers);
           
            
            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            Console.WriteLine(httpResponse);
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                Console.Write(result);
            }
            
        }
    }
}
